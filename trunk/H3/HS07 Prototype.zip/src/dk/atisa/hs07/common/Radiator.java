package dk.atisa.hs07.common;

public interface Radiator {

	/**
	 * Maximum temperature for control algorithm
	 */
	public static final double MAX_TEMPERATURE = 20.5;
	/**
	 * Minimum temperature for control algorithm
	 */
	public static final double MIN_TEMPERATURE = 19.5;

	/**
	 * Run the control algorithm upon notification of temperature change
	 * 
	 * @param _temperature
	 */
	public abstract void notify(String _temperature);

	public abstract void setState(boolean state);

	public abstract boolean getState();

}