package dk.atisa.hs07.common;

public interface Thermometer {
	double getTemperature();
}
