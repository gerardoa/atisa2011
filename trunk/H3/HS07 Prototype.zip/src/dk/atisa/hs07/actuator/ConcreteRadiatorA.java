package dk.atisa.hs07.actuator;

import dk.atisa.hs07.common.Radiator;

/**
 * An HS07 radiator that may be turned on and off
 * 
 * @author Klaus Marius Hansen, klaus.m.hansen@daimi.au.dk
 *
 */
public class ConcreteRadiatorA implements Radiator {
  private boolean state = false;

  /* (non-Javadoc)
 * @see dk.atisa.hs07.actuator.Radiator#notify(java.lang.String)
 */
  @Override
public void notify(String _temperature) {
    double temperature = Double.parseDouble(_temperature);
    if (temperature < MIN_TEMPERATURE) {
      System.out.println("Turn on radiator");
      setState(true);
    } else if (temperature > MAX_TEMPERATURE) {
      System.out.println("Turn off radiator");
      setState(false);
    } 
  }

  /* (non-Javadoc)
 * @see dk.atisa.hs07.actuator.Radiator#setState(boolean)
 */
@Override
public void setState(boolean state) {
    this.state = state;
  }

  /* (non-Javadoc)
 * @see dk.atisa.hs07.actuator.Radiator#getState()
 */
@Override
public boolean getState() {
    return state;
  }
}
